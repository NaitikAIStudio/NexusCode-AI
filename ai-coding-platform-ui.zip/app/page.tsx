"use client"

import { useState } from "react"
import { FileTree } from "@/components/code-editor/file-tree"
import { EditorPanel } from "@/components/code-editor/editor-panel"
import { AIChat } from "@/components/code-editor/ai-chat"
import { TerminalPanel } from "@/components/code-editor/terminal-panel"
import { PreviewPanel } from "@/components/code-editor/preview-panel"
import { ActivityBar, TopBar, StatusBar } from "@/components/code-editor/layout-components"
import { cn } from "@/lib/utils"
import { 
  PanelLeftClose, 
  PanelLeftOpen, 
  PanelRightClose, 
  PanelRightOpen,
  PanelBottomClose,
  PanelBottomOpen,
  Columns,
  Maximize2,
  GripVertical
} from "lucide-react"

export default function CodeEditorPage() {
  const [leftPanelOpen, setLeftPanelOpen] = useState(true)
  const [rightPanelOpen, setRightPanelOpen] = useState(true)
  const [bottomPanelOpen, setBottomPanelOpen] = useState(true)
  const [previewOpen, setPreviewOpen] = useState(true)

  return (
    <div className="h-screen flex flex-col overflow-hidden bg-background">
      {/* Top Bar */}
      <TopBar />

      {/* Main Content Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Activity Bar (Icon sidebar) */}
        <ActivityBar />

        {/* Left Panel - File Explorer */}
        <div
          className={cn(
            "border-r border-border/30 bg-sidebar/30 transition-all duration-300 overflow-hidden",
            leftPanelOpen ? "w-64" : "w-0"
          )}
        >
          {leftPanelOpen && <FileTree />}
        </div>

        {/* Center Area */}
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          {/* Panel Controls */}
          <div className="flex items-center justify-between px-2 py-1.5 border-b border-border/20 bg-background/30">
            <div className="flex items-center gap-1">
              <button
                onClick={() => setLeftPanelOpen(!leftPanelOpen)}
                className={cn(
                  "p-1.5 rounded-md transition-all",
                  leftPanelOpen ? "bg-secondary/50 text-foreground" : "text-muted-foreground hover:text-foreground hover:bg-secondary/30"
                )}
              >
                {leftPanelOpen ? <PanelLeftClose className="w-4 h-4" /> : <PanelLeftOpen className="w-4 h-4" />}
              </button>
              <button
                onClick={() => setBottomPanelOpen(!bottomPanelOpen)}
                className={cn(
                  "p-1.5 rounded-md transition-all",
                  bottomPanelOpen ? "bg-secondary/50 text-foreground" : "text-muted-foreground hover:text-foreground hover:bg-secondary/30"
                )}
              >
                {bottomPanelOpen ? <PanelBottomClose className="w-4 h-4" /> : <PanelBottomOpen className="w-4 h-4" />}
              </button>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setPreviewOpen(!previewOpen)}
                className={cn(
                  "flex items-center gap-1.5 px-2 py-1 rounded-md text-xs font-medium transition-all",
                  previewOpen ? "bg-primary/20 text-primary" : "text-muted-foreground hover:text-foreground hover:bg-secondary/30"
                )}
              >
                <Columns className="w-3.5 h-3.5" />
                Preview
              </button>
              <button
                onClick={() => setRightPanelOpen(!rightPanelOpen)}
                className={cn(
                  "p-1.5 rounded-md transition-all",
                  rightPanelOpen ? "bg-secondary/50 text-foreground" : "text-muted-foreground hover:text-foreground hover:bg-secondary/30"
                )}
              >
                {rightPanelOpen ? <PanelRightClose className="w-4 h-4" /> : <PanelRightOpen className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Editor + Preview Area */}
          <div className="flex-1 flex min-h-0 overflow-hidden">
            {/* Editor */}
            <div className={cn(
              "flex flex-col min-w-0 transition-all duration-300",
              previewOpen ? "flex-1" : "flex-1"
            )}>
              <div className="flex-1 p-2 min-h-0">
                <EditorPanel />
              </div>
            </div>

            {/* Resizer */}
            {previewOpen && (
              <div className="w-1 bg-border/20 hover:bg-primary/50 cursor-col-resize transition-colors flex items-center justify-center group">
                <GripVertical className="w-3 h-3 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            )}

            {/* Preview Panel */}
            {previewOpen && (
              <div className="flex-1 p-2 min-w-0">
                <PreviewPanel />
              </div>
            )}
          </div>

          {/* Bottom Panel - Terminal */}
          <div
            className={cn(
              "border-t border-border/30 transition-all duration-300 overflow-hidden",
              bottomPanelOpen ? "h-48" : "h-0"
            )}
          >
            {bottomPanelOpen && (
              <div className="h-full p-2 pt-0">
                <TerminalPanel />
              </div>
            )}
          </div>
        </div>

        {/* Right Panel - AI Chat */}
        <div
          className={cn(
            "border-l border-border/30 bg-sidebar/30 transition-all duration-300 overflow-hidden",
            rightPanelOpen ? "w-80 lg:w-96" : "w-0"
          )}
        >
          {rightPanelOpen && (
            <div className="h-full p-2">
              <AIChat />
            </div>
          )}
        </div>
      </div>

      {/* Status Bar */}
      <StatusBar />

      {/* Glow Effects */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-40 -left-40 w-80 h-80 bg-primary/10 rounded-full blur-[100px] animate-pulse-glow" />
        <div className="absolute -bottom-40 -right-40 w-80 h-80 bg-accent/10 rounded-full blur-[100px] animate-pulse-glow" style={{ animationDelay: "1s" }} />
      </div>
    </div>
  )
}
