"use client"

import { useState } from "react"
import { Terminal as TerminalIcon, X, Plus, ChevronDown, Maximize2, Minimize2 } from "lucide-react"
import { cn } from "@/lib/utils"

interface TerminalTab {
  id: string
  name: string
  type: "terminal" | "problems" | "output" | "debug"
}

const tabs: TerminalTab[] = [
  { id: "1", name: "Terminal", type: "terminal" },
  { id: "2", name: "Problems", type: "problems" },
  { id: "3", name: "Output", type: "output" },
  { id: "4", name: "Debug Console", type: "debug" },
]

const terminalLines = [
  { type: "command", content: "pnpm dev" },
  { type: "output", content: "" },
  { type: "info", content: "  VITE v5.2.0  ready in 234 ms" },
  { type: "output", content: "" },
  { type: "success", content: "  ➜  Local:   http://localhost:5173/" },
  { type: "muted", content: "  ➜  Network: use --host to expose" },
  { type: "muted", content: "  ➜  press h + enter to show help" },
  { type: "output", content: "" },
  { type: "info", content: "[TypeScript] Found 0 errors. Watching for file changes." },
  { type: "output", content: "" },
  { type: "warning", content: "[HMR] Connecting..." },
  { type: "success", content: "[HMR] Connected." },
  { type: "output", content: "" },
  { type: "info", content: "✓ Compiled successfully in 156ms" },
  { type: "output", content: "" },
]

function getLineColor(type: string) {
  switch (type) {
    case "command":
      return "text-primary"
    case "success":
      return "text-green-400"
    case "warning":
      return "text-yellow-400"
    case "error":
      return "text-red-400"
    case "info":
      return "text-blue-400"
    case "muted":
      return "text-muted-foreground"
    default:
      return "text-foreground"
  }
}

export function TerminalPanel() {
  const [activeTab, setActiveTab] = useState("1")
  const [isMaximized, setIsMaximized] = useState(false)

  return (
    <div className={cn(
      "flex flex-col glass-strong rounded-lg overflow-hidden transition-all duration-300",
      isMaximized ? "h-[400px]" : "h-full"
    )}>
      {/* Header */}
      <div className="flex items-center justify-between border-b border-border/30 bg-background/30">
        <div className="flex items-center">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                "flex items-center gap-2 px-4 py-2 text-xs font-medium transition-all border-b-2",
                activeTab === tab.id
                  ? "text-primary border-primary bg-secondary/30"
                  : "text-muted-foreground border-transparent hover:text-foreground hover:bg-secondary/20"
              )}
            >
              {tab.type === "terminal" && <TerminalIcon className="w-3.5 h-3.5" />}
              {tab.name}
              {tab.type === "problems" && (
                <span className="px-1.5 py-0.5 rounded-full bg-yellow-500/20 text-yellow-400 text-[10px]">
                  2
                </span>
              )}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1 px-2">
          <button className="p-1.5 rounded hover:bg-secondary/50 transition-colors">
            <Plus className="w-3.5 h-3.5 text-muted-foreground" />
          </button>
          <button 
            className="p-1.5 rounded hover:bg-secondary/50 transition-colors"
            onClick={() => setIsMaximized(!isMaximized)}
          >
            {isMaximized ? (
              <Minimize2 className="w-3.5 h-3.5 text-muted-foreground" />
            ) : (
              <Maximize2 className="w-3.5 h-3.5 text-muted-foreground" />
            )}
          </button>
          <button className="p-1.5 rounded hover:bg-secondary/50 transition-colors">
            <X className="w-3.5 h-3.5 text-muted-foreground" />
          </button>
        </div>
      </div>

      {/* Terminal Content */}
      <div className="flex-1 overflow-auto p-4 font-mono text-xs">
        <div className="flex items-center gap-2 mb-3 text-muted-foreground">
          <ChevronDown className="w-3 h-3" />
          <span className="text-[10px] uppercase tracking-wider">bash - nexus-project</span>
        </div>
        {terminalLines.map((line, index) => (
          <div key={index} className={cn("leading-6", getLineColor(line.type))}>
            {line.type === "command" ? (
              <span>
                <span className="text-primary">❯</span>{" "}
                <span className="text-foreground">{line.content}</span>
              </span>
            ) : (
              line.content
            )}
            {line.content === "" && <br />}
          </div>
        ))}
        <div className="flex items-center mt-2">
          <span className="text-primary">❯</span>
          <span className="ml-2 w-2 h-4 bg-primary animate-blink" />
        </div>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between px-4 py-1.5 border-t border-border/30 bg-background/30 text-[10px] text-muted-foreground">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
            bash
          </span>
          <span>node v20.11.0</span>
        </div>
        <div className="flex items-center gap-3">
          <span>UTF-8</span>
          <span>LF</span>
        </div>
      </div>
    </div>
  )
}
