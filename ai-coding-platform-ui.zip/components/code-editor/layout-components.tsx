"use client"

import { useState } from "react"
import {
  Code2,
  Folder,
  Search,
  GitBranch,
  Bug,
  Boxes,
  Settings,
  User,
  HelpCircle,
  Bell,
  Command,
  Sparkles,
  Play,
  Share2,
  Moon,
  Layers,
  Terminal,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface SidebarItem {
  id: string
  icon: React.ElementType
  label: string
  badge?: number
}

const topItems: SidebarItem[] = [
  { id: "files", icon: Folder, label: "Explorer" },
  { id: "search", icon: Search, label: "Search" },
  { id: "git", icon: GitBranch, label: "Source Control", badge: 3 },
  { id: "debug", icon: Bug, label: "Run and Debug" },
  { id: "extensions", icon: Boxes, label: "Extensions" },
  { id: "ai", icon: Sparkles, label: "AI Assistant" },
]

const bottomItems: SidebarItem[] = [
  { id: "terminal", icon: Terminal, label: "Terminal" },
  { id: "settings", icon: Settings, label: "Settings" },
  { id: "account", icon: User, label: "Account" },
]

export function ActivityBar() {
  const [activeItem, setActiveItem] = useState("files")

  return (
    <div className="w-14 h-full flex flex-col items-center py-3 border-r border-border/30 bg-sidebar/50">
      {/* Logo */}
      <div className="mb-4 p-2">
        <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/20">
          <Code2 className="w-5 h-5 text-primary-foreground" />
        </div>
      </div>

      {/* Top Items */}
      <div className="flex-1 flex flex-col items-center gap-1">
        {topItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveItem(item.id)}
            className={cn(
              "relative w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-200 group",
              activeItem === item.id
                ? "bg-primary/20 text-primary"
                : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
            )}
          >
            {activeItem === item.id && (
              <span className="absolute left-0 w-0.5 h-5 bg-primary rounded-r-full" />
            )}
            <item.icon className="w-5 h-5" />
            {item.badge && (
              <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-primary text-[10px] font-bold text-primary-foreground flex items-center justify-center">
                {item.badge}
              </span>
            )}
            {/* Tooltip */}
            <span className="absolute left-12 px-2 py-1 rounded-md bg-popover text-popover-foreground text-xs font-medium opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity whitespace-nowrap z-50 shadow-lg">
              {item.label}
            </span>
          </button>
        ))}
      </div>

      {/* Bottom Items */}
      <div className="flex flex-col items-center gap-1">
        {bottomItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveItem(item.id)}
            className={cn(
              "relative w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-200 group",
              activeItem === item.id
                ? "bg-primary/20 text-primary"
                : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
            )}
          >
            <item.icon className="w-5 h-5" />
            <span className="absolute left-12 px-2 py-1 rounded-md bg-popover text-popover-foreground text-xs font-medium opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity whitespace-nowrap z-50 shadow-lg">
              {item.label}
            </span>
          </button>
        ))}
      </div>
    </div>
  )
}

export function TopBar() {
  return (
    <header className="h-12 flex items-center justify-between px-4 border-b border-border/30 bg-background/50 backdrop-blur-xl">
      {/* Left Section */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
            <Code2 className="w-4 h-4 text-primary-foreground" />
          </div>
          <span className="font-semibold text-sm tracking-tight">NexusCode</span>
        </div>
        <nav className="hidden md:flex items-center gap-1 text-sm">
          {["File", "Edit", "View", "Go", "Run", "Terminal", "Help"].map((item) => (
            <button
              key={item}
              className="px-2.5 py-1 rounded-md text-muted-foreground hover:text-foreground hover:bg-secondary/50 transition-all"
            >
              {item}
            </button>
          ))}
        </nav>
      </div>

      {/* Center - Command Palette */}
      <button className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-secondary/50 border border-border/30 hover:border-border hover:bg-secondary transition-all group">
        <Search className="w-3.5 h-3.5 text-muted-foreground" />
        <span className="text-xs text-muted-foreground">Search or run command...</span>
        <div className="flex items-center gap-0.5 ml-4">
          <kbd className="px-1.5 py-0.5 rounded bg-muted text-[10px] text-muted-foreground font-mono">⌘</kbd>
          <kbd className="px-1.5 py-0.5 rounded bg-muted text-[10px] text-muted-foreground font-mono">K</kbd>
        </div>
      </button>

      {/* Right Section */}
      <div className="flex items-center gap-2">
        <button className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary/10 text-primary hover:bg-primary/20 transition-all text-sm font-medium">
          <Play className="w-3.5 h-3.5" />
          Run
        </button>
        <button className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-secondary/50 hover:bg-secondary transition-all text-sm">
          <Share2 className="w-3.5 h-3.5" />
          Share
        </button>
        <div className="h-5 w-px bg-border/50 mx-1 hidden sm:block" />
        <button className="p-2 rounded-lg hover:bg-secondary/50 transition-all relative">
          <Bell className="w-4 h-4 text-muted-foreground" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-primary" />
        </button>
        <button className="p-2 rounded-lg hover:bg-secondary/50 transition-all">
          <Moon className="w-4 h-4 text-muted-foreground" />
        </button>
        <button className="ml-1 w-8 h-8 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-primary-foreground text-xs font-bold">
          JD
        </button>
      </div>
    </header>
  )
}

export function StatusBar() {
  return (
    <footer className="h-6 flex items-center justify-between px-3 border-t border-border/30 bg-primary/5 text-[11px]">
      {/* Left */}
      <div className="flex items-center gap-3">
        <button className="flex items-center gap-1.5 px-2 py-0.5 rounded hover:bg-secondary/50 transition-colors">
          <GitBranch className="w-3 h-3" />
          <span>main</span>
        </button>
        <button className="flex items-center gap-1.5 px-2 py-0.5 rounded hover:bg-secondary/50 transition-colors">
          <Layers className="w-3 h-3" />
          <span>0 Problems</span>
        </button>
        <button className="flex items-center gap-1.5 px-2 py-0.5 rounded hover:bg-secondary/50 transition-colors text-yellow-400">
          <span>⚠</span>
          <span>2 Warnings</span>
        </button>
      </div>

      {/* Right */}
      <div className="flex items-center gap-3 text-muted-foreground">
        <span className="flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
          Connected
        </span>
        <span>TypeScript</span>
        <span>UTF-8</span>
        <span>LF</span>
        <button className="flex items-center gap-1 hover:text-foreground transition-colors">
          <Sparkles className="w-3 h-3 text-primary" />
          AI Ready
        </button>
      </div>
    </footer>
  )
}
