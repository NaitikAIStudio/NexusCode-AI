"use client"

import { useState } from "react"
import { ChevronRight, ChevronDown, File, Folder, FolderOpen, Plus, MoreHorizontal, Search } from "lucide-react"
import { cn } from "@/lib/utils"
import { Input } from "@/components/ui/input"

interface FileNode {
  id: string
  name: string
  type: "file" | "folder"
  children?: FileNode[]
  icon?: string
}

const fileStructure: FileNode[] = [
  {
    id: "1",
    name: "src",
    type: "folder",
    children: [
      {
        id: "2",
        name: "components",
        type: "folder",
        children: [
          { id: "3", name: "Header.tsx", type: "file", icon: "tsx" },
          { id: "4", name: "Button.tsx", type: "file", icon: "tsx" },
          { id: "5", name: "Card.tsx", type: "file", icon: "tsx" },
        ],
      },
      {
        id: "6",
        name: "hooks",
        type: "folder",
        children: [
          { id: "7", name: "useAuth.ts", type: "file", icon: "ts" },
          { id: "8", name: "useTheme.ts", type: "file", icon: "ts" },
        ],
      },
      {
        id: "9",
        name: "pages",
        type: "folder",
        children: [
          { id: "10", name: "index.tsx", type: "file", icon: "tsx" },
          { id: "11", name: "dashboard.tsx", type: "file", icon: "tsx" },
          { id: "12", name: "settings.tsx", type: "file", icon: "tsx" },
        ],
      },
      { id: "13", name: "App.tsx", type: "file", icon: "tsx" },
      { id: "14", name: "main.tsx", type: "file", icon: "tsx" },
    ],
  },
  {
    id: "15",
    name: "public",
    type: "folder",
    children: [
      { id: "16", name: "favicon.ico", type: "file", icon: "ico" },
      { id: "17", name: "logo.svg", type: "file", icon: "svg" },
    ],
  },
  { id: "18", name: "package.json", type: "file", icon: "json" },
  { id: "19", name: "tsconfig.json", type: "file", icon: "json" },
  { id: "20", name: "README.md", type: "file", icon: "md" },
]

function getFileColor(icon?: string) {
  switch (icon) {
    case "tsx":
    case "ts":
      return "text-blue-400"
    case "json":
      return "text-yellow-400"
    case "md":
      return "text-gray-400"
    case "svg":
      return "text-orange-400"
    default:
      return "text-muted-foreground"
  }
}

function FileTreeItem({
  node,
  depth = 0,
  selectedFile,
  onSelectFile,
}: {
  node: FileNode
  depth?: number
  selectedFile: string | null
  onSelectFile: (id: string) => void
}) {
  const [isOpen, setIsOpen] = useState(depth < 1)
  const hasChildren = node.children && node.children.length > 0

  return (
    <div className="select-none">
      <div
        className={cn(
          "flex items-center gap-1 px-2 py-1 rounded-md cursor-pointer transition-all duration-200 group",
          "hover:bg-secondary/50",
          selectedFile === node.id && "bg-primary/10 text-primary"
        )}
        style={{ paddingLeft: `${depth * 12 + 8}px` }}
        onClick={() => {
          if (node.type === "folder") {
            setIsOpen(!isOpen)
          } else {
            onSelectFile(node.id)
          }
        }}
      >
        {node.type === "folder" ? (
          <>
            <span className="w-4 h-4 flex items-center justify-center text-muted-foreground">
              {isOpen ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            </span>
            {isOpen ? (
              <FolderOpen className="w-4 h-4 text-primary/80" />
            ) : (
              <Folder className="w-4 h-4 text-muted-foreground" />
            )}
          </>
        ) : (
          <>
            <span className="w-4 h-4" />
            <File className={cn("w-4 h-4", getFileColor(node.icon))} />
          </>
        )}
        <span className="text-sm truncate flex-1">{node.name}</span>
        <MoreHorizontal className="w-3.5 h-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
      </div>
      {hasChildren && isOpen && (
        <div className="animate-in slide-in-from-top-1 duration-200">
          {node.children!.map((child) => (
            <FileTreeItem
              key={child.id}
              node={child}
              depth={depth + 1}
              selectedFile={selectedFile}
              onSelectFile={onSelectFile}
            />
          ))}
        </div>
      )}
    </div>
  )
}

export function FileTree() {
  const [selectedFile, setSelectedFile] = useState<string | null>("13")
  const [searchQuery, setSearchQuery] = useState("")

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-3 border-b border-border/50">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Explorer</h2>
          <button className="p-1 rounded hover:bg-secondary transition-colors">
            <Plus className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input
            placeholder="Search files..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="h-8 pl-8 text-xs bg-secondary/50 border-border/50 focus:border-primary/50"
          />
        </div>
      </div>

      {/* File Tree */}
      <div className="flex-1 overflow-auto p-2">
        <div className="mb-2">
          <div className="flex items-center gap-2 px-2 py-1.5 text-xs font-medium text-muted-foreground uppercase tracking-wider">
            <Folder className="w-3.5 h-3.5" />
            <span>nexus-project</span>
          </div>
        </div>
        {fileStructure.map((node) => (
          <FileTreeItem
            key={node.id}
            node={node}
            selectedFile={selectedFile}
            onSelectFile={setSelectedFile}
          />
        ))}
      </div>

      {/* Footer Stats */}
      <div className="p-3 border-t border-border/50">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>20 files</span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            Synced
          </span>
        </div>
      </div>
    </div>
  )
}
