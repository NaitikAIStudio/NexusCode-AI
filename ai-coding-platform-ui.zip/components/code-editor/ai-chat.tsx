"use client"

import { useState, useRef, useEffect } from "react"
import { Send, Sparkles, Copy, ThumbsUp, ThumbsDown, RotateCcw, Code, Lightbulb, Bug, Zap } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  code?: string
  timestamp: Date
}

const initialMessages: Message[] = [
  {
    id: "1",
    role: "assistant",
    content: "Hello! I'm NexusAI, your intelligent coding assistant. I can help you with:\n\n• Writing and debugging code\n• Explaining complex concepts\n• Refactoring and optimization\n• Code reviews and best practices\n\nWhat would you like to work on today?",
    timestamp: new Date(),
  },
  {
    id: "2",
    role: "user",
    content: "Can you help me create a custom React hook for handling form validation?",
    timestamp: new Date(),
  },
  {
    id: "3",
    role: "assistant",
    content: "I'd be happy to help you create a custom form validation hook! Here's a flexible and reusable implementation:",
    code: `import { useState, useCallback } from 'react'

interface ValidationRules {
  required?: boolean
  minLength?: number
  maxLength?: number
  pattern?: RegExp
  custom?: (value: string) => string | null
}

interface FormField {
  value: string
  error: string | null
  touched: boolean
}

export function useFormValidation<T extends Record<string, ValidationRules>>(
  rules: T
) {
  const [fields, setFields] = useState<Record<keyof T, FormField>>(() => {
    const initial: Record<string, FormField> = {}
    for (const key of Object.keys(rules)) {
      initial[key] = { value: '', error: null, touched: false }
    }
    return initial as Record<keyof T, FormField>
  })

  const validate = useCallback((name: keyof T, value: string) => {
    const fieldRules = rules[name]
    
    if (fieldRules.required && !value.trim()) {
      return 'This field is required'
    }
    if (fieldRules.minLength && value.length < fieldRules.minLength) {
      return \`Minimum \${fieldRules.minLength} characters\`
    }
    if (fieldRules.pattern && !fieldRules.pattern.test(value)) {
      return 'Invalid format'
    }
    if (fieldRules.custom) {
      return fieldRules.custom(value)
    }
    return null
  }, [rules])

  return { fields, validate, setFields }
}`,
    timestamp: new Date(),
  },
]

const quickActions = [
  { icon: Code, label: "Generate", color: "text-blue-400" },
  { icon: Bug, label: "Debug", color: "text-red-400" },
  { icon: Lightbulb, label: "Explain", color: "text-yellow-400" },
  { icon: Zap, label: "Optimize", color: "text-green-400" },
]

export function AIChat() {
  const [messages, setMessages] = useState<Message[]>(initialMessages)
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSend = () => {
    if (!input.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsTyping(true)

    // Simulate AI response
    setTimeout(() => {
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: "I understand you want to " + input.toLowerCase() + ". Let me help you with that...",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, aiMessage])
      setIsTyping(false)
    }, 1500)
  }

  return (
    <div className="h-full flex flex-col glass-strong rounded-lg overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-border/30 bg-gradient-to-r from-primary/10 to-accent/10">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 rounded-full border-2 border-background" />
          </div>
          <div>
            <h3 className="font-semibold text-sm">NexusAI Assistant</h3>
            <p className="text-xs text-muted-foreground">Always ready to help</p>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="flex items-center gap-2 p-3 border-b border-border/20">
        {quickActions.map((action) => (
          <button
            key={action.label}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-secondary/50 hover:bg-secondary text-xs font-medium transition-all hover:scale-105"
          >
            <action.icon className={cn("w-3.5 h-3.5", action.color)} />
            {action.label}
          </button>
        ))}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={cn(
              "flex gap-3 animate-in fade-in slide-in-from-bottom-2 duration-300",
              message.role === "user" && "flex-row-reverse"
            )}
          >
            {message.role === "assistant" && (
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center flex-shrink-0">
                <Sparkles className="w-4 h-4 text-primary-foreground" />
              </div>
            )}
            <div
              className={cn(
                "flex-1 max-w-[85%]",
                message.role === "user" && "flex flex-col items-end"
              )}
            >
              <div
                className={cn(
                  "rounded-2xl px-4 py-3",
                  message.role === "user"
                    ? "bg-primary text-primary-foreground rounded-br-md"
                    : "bg-secondary/50 rounded-bl-md"
                )}
              >
                <p className="text-sm whitespace-pre-wrap leading-relaxed">{message.content}</p>
              </div>
              {message.code && (
                <div className="mt-3 rounded-xl overflow-hidden border border-border/30 bg-background/50">
                  <div className="flex items-center justify-between px-4 py-2 border-b border-border/30 bg-secondary/30">
                    <span className="text-xs font-medium text-muted-foreground">TypeScript</span>
                    <button className="p-1 rounded hover:bg-secondary transition-colors">
                      <Copy className="w-3.5 h-3.5 text-muted-foreground" />
                    </button>
                  </div>
                  <pre className="p-4 text-xs font-mono overflow-x-auto">
                    <code>{message.code}</code>
                  </pre>
                </div>
              )}
              {message.role === "assistant" && (
                <div className="flex items-center gap-2 mt-2">
                  <button className="p-1 rounded hover:bg-secondary/50 transition-colors">
                    <ThumbsUp className="w-3.5 h-3.5 text-muted-foreground hover:text-primary" />
                  </button>
                  <button className="p-1 rounded hover:bg-secondary/50 transition-colors">
                    <ThumbsDown className="w-3.5 h-3.5 text-muted-foreground hover:text-destructive" />
                  </button>
                  <button className="p-1 rounded hover:bg-secondary/50 transition-colors">
                    <Copy className="w-3.5 h-3.5 text-muted-foreground" />
                  </button>
                  <button className="p-1 rounded hover:bg-secondary/50 transition-colors">
                    <RotateCcw className="w-3.5 h-3.5 text-muted-foreground" />
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex gap-3 animate-in fade-in duration-300">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-primary-foreground animate-pulse" />
            </div>
            <div className="bg-secondary/50 rounded-2xl rounded-bl-md px-4 py-3">
              <div className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: "0ms" }} />
                <span className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: "150ms" }} />
                <span className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: "300ms" }} />
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 border-t border-border/30 bg-background/30">
        <div className="flex items-end gap-2">
          <div className="flex-1 relative">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault()
                  handleSend()
                }
              }}
              placeholder="Ask NexusAI anything..."
              className="w-full min-h-[44px] max-h-32 px-4 py-3 pr-12 rounded-xl bg-secondary/50 border border-border/30 focus:border-primary/50 focus:ring-1 focus:ring-primary/20 resize-none text-sm placeholder:text-muted-foreground outline-none transition-all"
              rows={1}
            />
            <Button
              size="icon"
              onClick={handleSend}
              disabled={!input.trim()}
              className="absolute right-2 bottom-2 h-8 w-8 rounded-lg bg-primary hover:bg-primary/90 disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
        <p className="text-xs text-muted-foreground mt-2 text-center">
          Press Enter to send, Shift + Enter for new line
        </p>
      </div>
    </div>
  )
}
