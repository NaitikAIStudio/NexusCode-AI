"use client"

import { useState } from "react"
import { RefreshCw, ExternalLink, Smartphone, Tablet, Monitor, RotateCcw, ChevronDown, Globe, Eye } from "lucide-react"
import { cn } from "@/lib/utils"

type ViewportSize = "mobile" | "tablet" | "desktop"

const viewportSizes: Record<ViewportSize, { width: number; icon: React.ElementType }> = {
  mobile: { width: 375, icon: Smartphone },
  tablet: { width: 768, icon: Tablet },
  desktop: { width: 1200, icon: Monitor },
}

export function PreviewPanel() {
  const [viewport, setViewport] = useState<ViewportSize>("desktop")
  const [isLoading, setIsLoading] = useState(false)
  const [url, setUrl] = useState("localhost:5173")

  const handleRefresh = () => {
    setIsLoading(true)
    setTimeout(() => setIsLoading(false), 1000)
  }

  return (
    <div className="h-full flex flex-col glass-strong rounded-lg overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-3 border-b border-border/30 bg-background/30">
        <div className="flex items-center gap-2">
          <Eye className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium">Live Preview</span>
          <span className="px-2 py-0.5 rounded-full bg-green-500/20 text-green-400 text-[10px] font-medium">
            LIVE
          </span>
        </div>
        <div className="flex items-center gap-1">
          {(Object.keys(viewportSizes) as ViewportSize[]).map((size) => {
            const { icon: Icon } = viewportSizes[size]
            return (
              <button
                key={size}
                onClick={() => setViewport(size)}
                className={cn(
                  "p-1.5 rounded transition-all",
                  viewport === size
                    ? "bg-primary/20 text-primary"
                    : "text-muted-foreground hover:bg-secondary/50"
                )}
              >
                <Icon className="w-4 h-4" />
              </button>
            )
          })}
        </div>
      </div>

      {/* URL Bar */}
      <div className="flex items-center gap-2 px-3 py-2 border-b border-border/20 bg-secondary/20">
        <button
          onClick={handleRefresh}
          className="p-1 rounded hover:bg-secondary/50 transition-colors"
        >
          <RefreshCw className={cn("w-3.5 h-3.5 text-muted-foreground", isLoading && "animate-spin")} />
        </button>
        <button className="p-1 rounded hover:bg-secondary/50 transition-colors">
          <RotateCcw className="w-3.5 h-3.5 text-muted-foreground" />
        </button>
        <div className="flex-1 flex items-center gap-2 px-3 py-1.5 rounded-md bg-background/50 border border-border/30">
          <Globe className="w-3.5 h-3.5 text-muted-foreground" />
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            className="flex-1 bg-transparent text-xs outline-none placeholder:text-muted-foreground"
          />
          <span className="px-1.5 py-0.5 rounded bg-green-500/20 text-green-400 text-[10px]">
            HTTPS
          </span>
        </div>
        <button className="p-1 rounded hover:bg-secondary/50 transition-colors">
          <ExternalLink className="w-3.5 h-3.5 text-muted-foreground" />
        </button>
      </div>

      {/* Preview Content */}
      <div className="flex-1 bg-gradient-to-br from-secondary/20 to-background/50 p-4 overflow-auto">
        <div
          className={cn(
            "mx-auto bg-white rounded-lg shadow-2xl transition-all duration-500 overflow-hidden",
            viewport === "mobile" && "max-w-[375px]",
            viewport === "tablet" && "max-w-[768px]",
            viewport === "desktop" && "max-w-full"
          )}
          style={{ minHeight: "calc(100% - 2rem)" }}
        >
          {/* Simulated App Preview */}
          <div className="h-full bg-gradient-to-br from-slate-900 to-slate-800 text-white">
            {/* App Header */}
            <header className="flex items-center justify-between p-4 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-400 to-blue-500" />
                <span className="font-semibold text-sm">NexusApp</span>
              </div>
              <nav className="hidden md:flex items-center gap-6 text-sm text-white/70">
                <span className="hover:text-white cursor-pointer transition-colors">Dashboard</span>
                <span className="hover:text-white cursor-pointer transition-colors">Projects</span>
                <span className="hover:text-white cursor-pointer transition-colors">Settings</span>
              </nav>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-400 to-pink-500" />
              </div>
            </header>

            {/* App Content */}
            <main className="p-6">
              <div className="mb-6">
                <h1 className="text-2xl font-bold mb-2">Welcome back, Developer</h1>
                <p className="text-white/60 text-sm">Here&apos;s what&apos;s happening with your projects today.</p>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                {[
                  { label: "Total Projects", value: "12", change: "+2" },
                  { label: "Active Tasks", value: "24", change: "+5" },
                  { label: "Completed", value: "156", change: "+12" },
                  { label: "Team Members", value: "8", change: "+1" },
                ].map((stat) => (
                  <div
                    key={stat.label}
                    className="p-4 rounded-xl bg-white/5 border border-white/10 backdrop-blur-sm"
                  >
                    <p className="text-xs text-white/50 mb-1">{stat.label}</p>
                    <div className="flex items-baseline gap-2">
                      <span className="text-2xl font-bold">{stat.value}</span>
                      <span className="text-xs text-green-400">{stat.change}</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Recent Activity */}
              <div className="rounded-xl bg-white/5 border border-white/10 p-4">
                <h3 className="font-medium mb-4 flex items-center gap-2">
                  Recent Activity
                  <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-400 text-xs">Live</span>
                </h3>
                <div className="space-y-3">
                  {[
                    { action: "Pushed to main", project: "nexus-ui", time: "2 min ago" },
                    { action: "Created branch", project: "api-service", time: "15 min ago" },
                    { action: "Merged PR #42", project: "dashboard", time: "1 hour ago" },
                  ].map((activity, i) => (
                    <div key={i} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
                      <div className="flex items-center gap-3">
                        <div className="w-2 h-2 rounded-full bg-cyan-400" />
                        <span className="text-sm">{activity.action}</span>
                        <span className="text-xs text-white/40">{activity.project}</span>
                      </div>
                      <span className="text-xs text-white/40">{activity.time}</span>
                    </div>
                  ))}
                </div>
              </div>
            </main>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between px-4 py-2 border-t border-border/30 bg-background/30 text-xs text-muted-foreground">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
            Hot Reload Active
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span>{viewportSizes[viewport].width}px</span>
          <ChevronDown className="w-3 h-3" />
        </div>
      </div>
    </div>
  )
}
