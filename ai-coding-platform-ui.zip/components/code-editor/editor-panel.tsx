"use client"

import { useState } from "react"
import { X, Circle, ChevronDown, Sparkles, Copy, RotateCcw, Settings } from "lucide-react"
import { cn } from "@/lib/utils"

interface Tab {
  id: string
  name: string
  language: string
  modified: boolean
}

const tabs: Tab[] = [
  { id: "1", name: "App.tsx", language: "tsx", modified: true },
  { id: "2", name: "Header.tsx", language: "tsx", modified: false },
  { id: "3", name: "useAuth.ts", language: "ts", modified: false },
]

const codeContent = `import { useState, useEffect } from 'react'
import { Header } from './components/Header'
import { Dashboard } from './pages/Dashboard'
import { useAuth } from './hooks/useAuth'
import { ThemeProvider } from './context/ThemeContext'

interface AppProps {
  initialRoute?: string
}

export function App({ initialRoute = '/' }: AppProps) {
  const [currentRoute, setCurrentRoute] = useState(initialRoute)
  const { user, isLoading, login, logout } = useAuth()

  useEffect(() => {
    // Initialize analytics
    if (user) {
      analytics.identify(user.id, {
        email: user.email,
        name: user.name,
      })
    }
  }, [user])

  const handleNavigation = (route: string) => {
    setCurrentRoute(route)
    window.history.pushState({}, '', route)
  }

  if (isLoading) {
    return (
      <div className="loading-container">
        <Spinner size="lg" />
      </div>
    )
  }

  return (
    <ThemeProvider defaultTheme="dark">
      <div className="app-container">
        <Header 
          user={user}
          onLogout={logout}
          onNavigate={handleNavigation}
        />
        <main className="main-content">
          {currentRoute === '/' && <Dashboard user={user} />}
          {currentRoute === '/settings' && <Settings />}
        </main>
      </div>
    </ThemeProvider>
  )
}`

function highlightCode(code: string) {
  const lines = code.split("\n")
  return lines.map((line, index) => {
    let highlighted = line
      // Keywords
      .replace(
        /\b(import|export|from|const|let|var|function|return|if|else|interface|type|useState|useEffect|default)\b/g,
        '<span class="syntax-keyword">$1</span>'
      )
      // Strings
      .replace(
        /(['"`])(.*?)\1/g,
        '<span class="syntax-string">$1$2$1</span>'
      )
      // Functions
      .replace(
        /\b([a-zA-Z_][a-zA-Z0-9_]*)\s*\(/g,
        '<span class="syntax-function">$1</span>('
      )
      // Comments
      .replace(
        /(\/\/.*$)/g,
        '<span class="syntax-comment">$1</span>'
      )
      // Types after :
      .replace(
        /:\s*([A-Z][a-zA-Z0-9_]*)/g,
        ': <span class="text-yellow-400">$1</span>'
      )

    return { lineNumber: index + 1, content: highlighted }
  })
}

export function EditorPanel() {
  const [activeTab, setActiveTab] = useState("1")
  const [cursorLine, setCursorLine] = useState(12)
  const highlightedCode = highlightCode(codeContent)

  return (
    <div className="h-full flex flex-col glass-strong rounded-lg overflow-hidden">
      {/* Tab Bar */}
      <div className="flex items-center border-b border-border/30 bg-background/30">
        <div className="flex-1 flex items-center overflow-x-auto scrollbar-hide">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                "flex items-center gap-2 px-4 py-2.5 border-r border-border/20 transition-all duration-200 min-w-fit group",
                activeTab === tab.id
                  ? "bg-secondary/50 text-foreground"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary/30"
              )}
            >
              <span className="text-sm">{tab.name}</span>
              {tab.modified && (
                <Circle className="w-2 h-2 fill-primary text-primary" />
              )}
              <X className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 hover:text-destructive transition-all" />
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1 px-3">
          <button className="p-1.5 rounded hover:bg-secondary/50 transition-colors group">
            <Sparkles className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
          </button>
          <button className="p-1.5 rounded hover:bg-secondary/50 transition-colors">
            <Settings className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>
      </div>

      {/* Breadcrumb */}
      <div className="flex items-center gap-1 px-4 py-2 text-xs text-muted-foreground border-b border-border/20 bg-background/20">
        <span>src</span>
        <ChevronDown className="w-3 h-3 rotate-[-90deg]" />
        <span>App.tsx</span>
        <ChevronDown className="w-3 h-3 rotate-[-90deg]" />
        <span className="text-foreground">App</span>
      </div>

      {/* Code Editor */}
      <div className="flex-1 overflow-auto font-mono text-sm leading-6">
        <div className="min-w-fit">
          {highlightedCode.map((line) => (
            <div
              key={line.lineNumber}
              className={cn(
                "flex hover:bg-secondary/20 transition-colors cursor-text",
                cursorLine === line.lineNumber && "bg-primary/5 border-l-2 border-primary"
              )}
              onClick={() => setCursorLine(line.lineNumber)}
            >
              <span className="line-number py-0.5 pr-4 pl-4 text-right select-none min-w-[3.5rem] border-r border-border/20">
                {line.lineNumber}
              </span>
              <pre
                className="py-0.5 px-4 flex-1"
                dangerouslySetInnerHTML={{ __html: line.content || "&nbsp;" }}
              />
            </div>
          ))}
        </div>
      </div>

      {/* Status Bar */}
      <div className="flex items-center justify-between px-4 py-1.5 border-t border-border/30 bg-background/30 text-xs text-muted-foreground">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-primary" />
            TypeScript React
          </span>
          <span>UTF-8</span>
          <span>LF</span>
        </div>
        <div className="flex items-center gap-4">
          <span>Ln {cursorLine}, Col 1</span>
          <span>Spaces: 2</span>
          <button className="flex items-center gap-1 hover:text-foreground transition-colors">
            <Copy className="w-3.5 h-3.5" />
          </button>
          <button className="flex items-center gap-1 hover:text-foreground transition-colors">
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  )
}
